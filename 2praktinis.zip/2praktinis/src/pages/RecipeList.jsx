import { useState, useEffect } from "react";
import RecipeCard from "../components/RecipeCard";
import Pagination from "../components/Pagination";

const RecipeList = () => {
    const [recipes, setRecipes] = useState([]);
    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        setLoading(true);
        setError(null);

        fetch(`https://dummyjson.com/recipes?limit=5&skip=${(page - 1) * 5}`) // Gauna 5 receptus pagal puslapio numerį
            .then((res) => res.json())
            .then((data) => {
                if (data.recipes) {
                    setRecipes(data.recipes);
                } else {
                    setRecipes([]);
                    setError("No recipes found.");
                }
            })
            .catch((err) => {
                console.error("Error fetching recipes:", err);
                setError("Failed to load recipes.");
            })
            .finally(() => setLoading(false));
    }, [page]); // Kiekvieną kartą pasikeitus puslapiui, vėl užkrauna receptus

    return (
        <div>
            {loading && <p>Loading recipes...</p>}
            {error && <p style={{ color: "red" }}>{error}</p>}

            {!loading && !error && recipes.length > 0 ? (
                recipes.map((recipe) => (
                    <RecipeCard key={recipe.id} recipe={recipe} />
                ))
            ) : (
                !loading && !error && <p>No recipes available.</p>
            )}

            <Pagination page={page} setPage={setPage} /> {/* Prideda puslapiavimo mygtukus */}
        </div>
    );
};

export default RecipeList;
