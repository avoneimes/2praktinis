import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate, Link } from "react-router-dom";
import RecipeList from "../pages/RecipeList";

const Dashboard = () => {
    const { user, logout } = useContext(AuthContext); // Gaunam vartotojo informaciją ir atsijungimo funkciją
    const navigate = useNavigate(); // Leidžia naviguoti tarp puslapių

    const handleLogout = () => {
        logout(); // Išvalom vartotojo duomenis iš globalios būsenos
        navigate("/login"); // Peradresuojam į prisijungimo puslapį
    };

    return (
        <div>
            <h2>Sveiki, {user?.email}</h2> {/* Rodomas prisijungusio vartotojo el. paštas */}
            <button onClick={handleLogout}>Atsijungti</button>

            <button>
                <Link to="/favorites">💖 Mano mėgstami receptai</Link>
            </button>

            <h2>Receptai</h2>
            <RecipeList /> {/* Čia įdedama receptų aplikacija */}
        </div>
    );
};

export default Dashboard;
