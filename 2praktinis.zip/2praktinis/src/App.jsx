import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext"; // Kontekstas autentifikacijai
import { FavoritesProvider } from "./context/FavoritesContext"; // Kontekstas mėgstamiems receptams
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Home from "./pages/Home";
import RecipeDetail from "./pages/RecipeDetail";
import FavoritesPage from "./pages/FavoritesPage";
import ProtectedRoute from "./components/ProtectedRoute";

function App() {
  return (
    <AuthProvider> {/* Globali autentifikacijos būsena */}
      <FavoritesProvider> {/* Globali mėgstamų receptų būsena */}
        <Router> {/* Puslapių maršrutų valdymas */}
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={
              <ProtectedRoute> {/* Apsaugotas maršrutas */}
                <Dashboard />
              </ProtectedRoute>
            } />
            <Route path="/recipe/:id" element={<RecipeDetail />} />
            <Route path="/favorites" element={<FavoritesPage />} />
          </Routes>
        </Router>
      </FavoritesProvider>
    </AuthProvider>
  );
}

export default App;
