import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Register = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate(); // Leidžia naviguoti tarp puslapių

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://localhost:5000/users", { email, password }); // Siunčia duomenis į serverį
            navigate("/login"); // Po registracijos nukreipia į prisijungimo puslapį
        } catch (err) {
            setError("Registracijos klaida.");
        }
    };

    return (
        <div>
            <h2>Registracija</h2>
            {error && <p>{error}</p>}
            <form onSubmit={handleSubmit}>
                <input type="email" placeholder="El. paštas" value={email} onChange={(e) => setEmail(e.target.value)} required />
                <input type="password" placeholder="Slaptažodis" value={password} onChange={(e) => setPassword(e.target.value)} required />
                <button type="submit">Registruotis</button>
            </form>
        </div>
    );
};

export default Register;
