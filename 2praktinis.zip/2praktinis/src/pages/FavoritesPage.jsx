import { useContext } from "react";
import { FavoritesContext } from "../context/FavoritesContext";
import RecipeCard from "../components/RecipeCard";

const FavoritesPage = () => {
    const { favorites } = useContext(FavoritesContext); // Gauna mėgstamų receptų sąrašą

    return (
        <div>
            <h2>Mano mėgstami receptai</h2>
            {favorites.length === 0 ? (
                <p>Jūs dar neturite mėgstamų receptų.</p>
            ) : (
                <div className="recipe-list">
                    {favorites.map((recipe) => (
                        <RecipeCard key={recipe.id} recipe={recipe} />
                    ))}
                </div>
            )}
        </div>
    );
};

export default FavoritesPage;
