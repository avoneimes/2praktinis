import { useContext } from "react";
import { FavoritesContext } from "../context/FavoritesContext";
import { Link } from "react-router-dom";

const RecipeCard = ({ recipe }) => {
    if (!recipe) return <div>Loading...</div>;

    const { toggleFavorite, favorites } = useContext(FavoritesContext);
    const isFavorite = favorites.some((fav) => fav.id === recipe.id); // Tikrina, ar receptas jau mėgstamas

    return (
        <div className="recipe-card">
            <h3>{recipe.name || "No Name"}</h3>
            <p>{recipe.description || "No Description"}</p>
            <button onClick={() => toggleFavorite(recipe)}>
                {isFavorite ? "💖" : "🤍"} Favorite
            </button>
            <Link to={`/recipe/${recipe.id}`}>View Details</Link> {/* Nuoroda į recepto detalų puslapį */}
        </div>
    );
};

export default RecipeCard;
