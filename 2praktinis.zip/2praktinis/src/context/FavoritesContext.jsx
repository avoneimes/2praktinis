import { createContext, useState, useEffect } from "react";

export const FavoritesContext = createContext();

export const FavoritesProvider = ({ children }) => {
    const [favorites, setFavorites] = useState([]);

    useEffect(() => {
        fetch("http://localhost:5000/favorites")
            .then((res) => res.json())
            .then((data) => setFavorites(data));
    }, []);

    const toggleFavorite = (recipe) => {
        if (favorites.some((fav) => fav.id === recipe.id)) {
            removeFavorite(recipe.id);
        } else {
            addFavorite(recipe);
        }
    };

    const addFavorite = (recipe) => {
        fetch("http://localhost:5000/favorites", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(recipe),
        })
            .then(() => setFavorites([...favorites, recipe]));
    };

    const removeFavorite = (id) => {
        fetch(`http://localhost:5000/favorites/${id}`, {
            method: "DELETE",
        })
            .then(() => setFavorites(favorites.filter((fav) => fav.id !== id)));
    };

    return (
        <FavoritesContext.Provider value={{ favorites, toggleFavorite }}>
            {children}
        </FavoritesContext.Provider>
    );
};
