import { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

const ProtectedRoute = ({ children }) => {
    const { user } = useContext(AuthContext); // Gaunam vartotojo duomenis iš globalios būsenos

    return user ? children : <Navigate to="/login" />; // Jei prisijungęs – rodo turinį, jei ne – siunčia į prisijungimo puslapį
};

export default ProtectedRoute;
