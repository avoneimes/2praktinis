import { Link } from "react-router-dom";

const Home = () => {
    return (
        <div className="auth-container">
            <h2>Pagrindinis puslapis</h2>
            <Link to="/login">Prisijungti</Link> | <Link to="/register">Registruotis</Link> {/* Nuorodos į prisijungimą ir registraciją */}
        </div>
    );
};

export default Home;
