import { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Login = () => {
    const [email, setEmail] = useState(""); // Įvestas el. paštas
    const [password, setPassword] = useState(""); // Įvestas slaptažodis
    const [error, setError] = useState(""); // Klaidų pranešimai
    const { login } = useContext(AuthContext); // Prisijungimo funkcija iš konteksto
    const navigate = useNavigate(); // Leidžia perkelti vartotoją į kitą puslapį

    const handleSubmit = async (e) => {
        e.preventDefault(); // Neleidžia puslapiui persikrauti

        const success = await login({ email, password }); // Bando prisijungti

        if (success) {
            navigate("/dashboard"); // Sėkmės atveju nukreipia į „Dashboard“
        } else {
            setError("Neteisingas el. paštas arba slaptažodis!"); // Jei klaida – rodo pranešimą
        }
    };

    return (
        <div className="auth-container">
            <form onSubmit={handleSubmit}>
                <h2>Prisijungimas</h2>
                <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                <input type="password" placeholder="Slaptažodis" value={password} onChange={(e) => setPassword(e.target.value)} required />
                <button type="submit">Prisijungti</button>
                {error && <p style={{ color: "red" }}>{error}</p>} {/* Jei klaida – rodomas pranešimas */}
            </form>
        </div>
    );
};

export default Login;
